import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactListComponent } from './Contact/contact-list/contact-list.component';
import { ContactDetailComponent } from './Contact/contact-detail/contact-detail.component';
import { ContactAddComponent} from './Contact/contact-add/contact-add.component';

const routes: Routes = 
[
  { path: '', redirectTo: 'Contacts', pathMatch: 'full' },
  { path: 'Contacts', component: ContactListComponent },
  { path: 'Contacts/:contactID', component: ContactDetailComponent },
  { path: 'AddContact/:contactID', component: ContactAddComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
