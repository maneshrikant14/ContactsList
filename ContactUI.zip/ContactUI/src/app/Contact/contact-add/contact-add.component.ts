import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder,Validators  } from '@angular/forms';
import { ContactsService } from 'src/app/services/contacts.service';

@Component({
  selector: 'app-contact-add',
  templateUrl: './contact-add.component.html',
  styleUrls: ['./contact-add.component.css']
})
export class ContactAddComponent implements OnInit {
  contactID : number;
  contactForm : any;
  submitted :boolean;

  constructor(private contactsService: ContactsService
          ,private formbulider: FormBuilder
          ,private route: ActivatedRoute
          ,private router: Router )
  { 
    this.submitted = false;
  }

  ngOnInit() {
    this.contactID = this.route.snapshot.params['contactID'];
    
    this.contactForm = this.formbulider.group({  
      FirstName: ['', [Validators.required]],  
      LastName: ['', [Validators.required]],  
      Email: ['', [Validators.required, Validators.email]],  
      PhoneNumber: ['', [Validators.required]],
      Status:['true']
    });  

  }

  get f() 
  { 
    return this.contactForm.controls; 
  }

  onFormSubmit()
  {
    this.submitted = true;

     if (this.contactForm.invalid) {
         return;
     }

    var result= this.contactsService.create(this.contactForm.value).subscribe({
      next: data => {
                      if(data != null && data.contactID > 0)
                      {
                          alert("Contact Added SuccessFully!");
                          this.router.navigate(['Contacts',  data.contactID ]);
                       
                      }

                      console.log(data);
                    },
      error: error => console.error('There was an error!', error)
    });

    console.log(result);

  }

  resetForm()
  {

  }
}
