import { Component, OnInit } from '@angular/core';
import { ContactsService } from 'src/app/services/contacts.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-contact-detail',
  templateUrl: './contact-detail.component.html',
  styleUrls: ['./contact-detail.component.css']
})
export class ContactDetailComponent implements OnInit {
  currentContact : any;
  contactID :number;

  constructor(private contactsService: ContactsService, private route: ActivatedRoute,private router: Router) 
  { }

  ngOnInit() {
    this.contactID = this.route.snapshot.params['contactID'];
    this.getContactDetails();
  }

  editContact(contactID) {
    this.router.navigate(['AddContact',  contactID ]);
  }


  deleteContact(contactID) {
    var confirmRes = confirm("Are you sure you wanted to delete the Contact?");
    if(confirmRes)
    { 
      
      var result= this.contactsService.delete(contactID).subscribe({
        next: data => {
                        alert("Contact Deleted SuccessFully!");
                        this.router.navigate(['/Contacts' ]);
  
                      },
        error: error => console.error('There was an error!', error)
      });

    }
  }


  getContactDetails() {
    this.contactsService.get(this.contactID)
      .subscribe(
        data => {
          this.currentContact = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }


}
