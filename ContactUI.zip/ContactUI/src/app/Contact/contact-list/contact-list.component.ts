import { Component, OnInit } from '@angular/core';
import { ContactsService } from 'src/app/services/contacts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {

  contacts: any;
  currentContact = null;
  currentIndex = -1;
  title = '';

  constructor(private contactsService: ContactsService
        ,private router: Router)
  {
  }

  ngOnInit() {
    this.retrieveContacts();
  }

  retrieveContacts() {
    this.contactsService.getAll()
      .subscribe(
        data => {
          this.contacts = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveContacts();
    this.currentContact = null;
    this.currentIndex = -1;
  }

  setActiveContact(contactID) {
    this.router.navigate(['Contacts',  contactID ]);
  }

  searchTitle() {
    this.contactsService.searchByName(this.title)
      .subscribe(
        data => {
          this.contacts = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }


}
