import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {environment} from './../../environments/environment';


const baseUrl = environment.contactsApiUrl;
const headers = new HttpHeaders().set("content-type", "application/json").set("accept", "application/json");

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(baseUrl);
  }

  get(id) {
    return this.http.get(`${baseUrl}/${id}`);
  }

  create(data) : Observable<any> {  
    return this.http.post(baseUrl, JSON.stringify(data),{headers : headers});
  }

  update(id, data) {
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  delete(id) {
    return this.http.delete(`${baseUrl}/${id}`,{headers : headers});
  }

  deleteAll() {
    return this.http.delete(baseUrl);
  }

  searchByName(title) {
    return this.http.get(`${baseUrl}?title=${title}`);
  }

}
