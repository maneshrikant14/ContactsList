export const environment = {
  production: true,
  contactsApiUrl : "http://localhost:49357/api/contacts",
};
